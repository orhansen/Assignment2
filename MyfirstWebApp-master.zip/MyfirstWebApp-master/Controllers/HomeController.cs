﻿using Microsoft.AspNetCore.Mvc;
using MyfirstWebApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyfirstWebApp.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet("Calculator")] //Get loads the page but passes nothing
        public IActionResult Calculator()
        {
            return View();
        }

        [HttpPost("Calculator")] //Post is what loads the object and allows the inputs to be posted when submitted
        public IActionResult Calculator(CalculatorModel model)
        {
            return View();
        }
    }
}
