﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MyfirstWebApp.Models
{
    //Class that stores all the values as an object, as well as validates that the values are in a range
    public class CalculatorModel
    {
        [Range(0, 100)]
        public int assignment { get;set; }
        [Range(0, 100)]
        public int gp { get;set; }
        [Range(0, 100)]
        public int quiz { get;set; }
        [Range(0, 100)]
        public int exam { get;set; }
        [Range(0, 100)]
        public int intex { get;set; }

    }
}
