﻿//Receives all the values from the form and assigns to variable
$("#submitButton").click(function () {
    var assignmentGrade = $("#assignment").val() * .50
    var projectGrade = $("#gp").val() * .10
    var quizGrade = $("#quiz").val() * .10
    var examGrade = $("#exam").val() * .20
    var intexGrade = $("#intex").val() * .10
    var finalGrade = assignmentGrade + projectGrade + quizGrade + examGrade + intexGrade
    var letterGrade = undefined

    //If statement to cycle through grade letter to match final score
    if (finalGrade >= 94) {
        letterGrade = "A"
    } else if (finalGrade >= 90) {
        letterGrade = "A-"
    } else if (finalGrade >= 87) {
        letterGrade = "B+"
    } else if (finalGrade >= 84) {
        letterGrade = "B"
    } else if (finalGrade >= 80) {
        letterGrade = "B-"
    } else if (finalGrade >= 77) {
        letterGrade = "C+"
    } else if (finalGrade >= 74) {
        letterGrade = "C"
    } else if (finalGrade >= 70) {
        letterGrade = "C-"
    } else if (finalGrade >= 67) {
        letterGrade = "D+"
    } else if (finalGrade >= 64) {
        letterGrade = "D"
    } else if (finalGrade >= 60) {
        letterGrade = "D-"
    } else {
        letterGrade = "E"
    }

    alert("Final Grade is: " + finalGrade + " (" + letterGrade + ")");
});